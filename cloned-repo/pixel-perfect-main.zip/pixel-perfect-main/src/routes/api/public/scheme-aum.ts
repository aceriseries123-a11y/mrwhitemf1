import { createFileRoute } from "@tanstack/react-router";

// Per-scheme AAUM (Average AUM, ₹ Cr) from AMFI India.
// AMFI publishes a quarterly CSV at:
//   https://www.amfiindia.com/modules/AverageAUMDetails (POST form, returns HTML/CSV)
// We try the public download endpoint that returns the latest quarter's CSV
// for *all* schemes, parse it, and cache in worker memory for 6h.
//
// Response: { asOf: string, count: number, aum: Record<schemeCode, number /* ₹ Cr */> }

type Cache = { at: number; asOf: string; aum: Record<string, number> };
let _cache: Cache | null = null;
const TTL_MS = 6 * 60 * 60 * 1000;

// AMFI's quarterly AAUM disclosure landing page lists the latest CSV.
// The download endpoint accepts a form POST returning a tab/comma file.
// Endpoint discovered from amfiindia.com/research-information/aum-data/average-aum
const AMFI_AAUM_ENDPOINT = "https://www.amfiindia.com/modules/AverageAUMDetails";

async function fetchAmfiAAUM(): Promise<Cache> {
  // POST form: AUmType=S (scheme-wise), AumCatType=1, MF_Id=-1, Year_Id=0, Year_Quarter (latest auto-selected when blank)
  const body = new URLSearchParams({
    AUmType: "S",
    AumCatType: "1",
    MF_Id: "-1",
    Year_Id: "0",
    Year_Quarter: "",
  });
  const res = await fetch(AMFI_AAUM_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "User-Agent": "Mozilla/5.0 QuantFund/1.0",
      Accept: "text/html,*/*",
    },
    body: body.toString(),
  });
  if (!res.ok) throw new Error(`AMFI AAUM ${res.status}`);
  const html = await res.text();

  // The response is HTML containing a <table> with rows:
  //   <td>AMC</td><td>Scheme Name</td><td>AAUM (Mgd by AMC) (₹ Cr)</td><td>AAUM (excl FoF) (₹ Cr)</td>...
  // Some quarters expose a Scheme Code column; when missing we match by scheme name.
  const aum: Record<string, number> = {};
  const rowRe = /<tr[^>]*>([\s\S]*?)<\/tr>/gi;
  const cellRe = /<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi;
  let m: RegExpExecArray | null;
  // First pass: detect column indexes from a header row
  let codeCol = -1;
  let nameCol = -1;
  let aumCol = -1;
  let asOf = "latest";
  const asOfM = html.match(/quarter\s+ended[^<]*<\/[^>]+>\s*<[^>]+>\s*([A-Za-z]+\s+\d{4})/i)
    || html.match(/Quarter\s+Ending\s*[:\-]?\s*([A-Za-z]+\s+\d{4})/i);
  if (asOfM) asOf = asOfM[1];

  while ((m = rowRe.exec(html))) {
    const row = m[1];
    const cells: string[] = [];
    let c: RegExpExecArray | null;
    cellRe.lastIndex = 0;
    while ((c = cellRe.exec(row))) {
      cells.push(c[1].replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").trim());
    }
    if (cells.length < 3) continue;
    if (codeCol === -1) {
      cells.forEach((cell, i) => {
        const v = cell.toLowerCase();
        if (codeCol === -1 && /scheme\s*code/.test(v)) codeCol = i;
        if (nameCol === -1 && /scheme\s*name/.test(v)) nameCol = i;
        if (aumCol === -1 && /aaum|average\s*aum/.test(v) && !/fof/i.test(cell)) aumCol = i;
      });
      continue;
    }
    if (codeCol === -1) continue;
    const code = cells[codeCol]?.replace(/\D/g, "");
    const aumStr = cells[aumCol >= 0 ? aumCol : cells.length - 1]?.replace(/,/g, "").trim();
    const aumVal = Number(aumStr);
    if (code && /^\d{5,6}$/.test(code) && Number.isFinite(aumVal) && aumVal > 0) {
      aum[code] = aumVal;
    }
  }

  return { at: Date.now(), asOf, aum };
}

export const Route = createFileRoute("/api/public/scheme-aum")({
  server: {
    handlers: {
      GET: async () => {
        try {
          if (!_cache || Date.now() - _cache.at > TTL_MS) {
            _cache = await fetchAmfiAAUM();
          }
          return new Response(
            JSON.stringify({ asOf: _cache.asOf, count: Object.keys(_cache.aum).length, aum: _cache.aum }),
            {
              status: 200,
              headers: {
                "Content-Type": "application/json",
                "Cache-Control": "public, max-age=21600",
                "Access-Control-Allow-Origin": "*",
              },
            },
          );
        } catch (e) {
          return new Response(
            JSON.stringify({ asOf: null, count: 0, aum: {}, error: String(e) }),
            { status: 200, headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" } },
          );
        }
      },
    },
  },
});